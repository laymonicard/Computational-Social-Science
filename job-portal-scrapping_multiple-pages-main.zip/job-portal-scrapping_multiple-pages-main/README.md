# Job-Portal-Scraping---Multiple-Pages
This project aims to provide a summary of jobs offered in each location from one of Indonesia's job listing website, Kalibrr. This time I performed it for multiple website pages, which is an enhancement from my previous trial with single page scraping.
