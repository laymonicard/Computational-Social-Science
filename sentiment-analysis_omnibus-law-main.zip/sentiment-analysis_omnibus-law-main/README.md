# sentiment analysis
This project aims to analyze Twitter sentiments over certain topics. In this example, I run through some tweets discussing about "Omnibus Law". 
This algorithm needs much improvements especially to remove too common words that are not really meaningful in revealing the sentiments. Moreover, if I want to identify topic prevalence, topic modelling is probably a more suitable method. 
